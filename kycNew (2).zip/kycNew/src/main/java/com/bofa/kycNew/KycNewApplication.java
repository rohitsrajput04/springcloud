package com.bofa.kycNew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KycNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycNewApplication.class, args);
	}

}
